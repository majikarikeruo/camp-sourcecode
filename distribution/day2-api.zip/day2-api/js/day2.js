/**
 * $()
 *
 * $().on('click', function() {
 *
 * })
 *
 * const season = "";
 * let votesCount = "";
 *
 *
 * if() {
 *
 * } else if() {
 *
 * } else {
 *
 * }
 *
 *
 * https://itunes.apple.com/search?lang=ja_JP&entry=music&media=music&country=JP&term=yoasobi
 *
 * $.getJSON(requestUrl, function (data) {
 *
 * }
 *
 *
 * array.forEach(element => {
 *
 * });
 */
