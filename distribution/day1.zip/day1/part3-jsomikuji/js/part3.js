/**
 * $()
 *
 * $().on('click', function() {
 *
 * })
 *
 * const season = "";
 * let votesCount = "";
 *
 *
 * if() {
 *
 * } else if() {
 *
 * } else {
 *
 * }
 */
